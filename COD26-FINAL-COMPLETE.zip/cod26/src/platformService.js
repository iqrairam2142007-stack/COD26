import { hasFirebaseConfig } from './firebase';

const STORAGE_KEY = 'cod26-platform-data';

const addDays = (baseDate, days) => {
  const nextDate = new Date(baseDate);
  nextDate.setDate(nextDate.getDate() + days);
  return nextDate;
};

const createInstallment = (index, baseDate, immediate = false) => {
  const cycleStart = new Date(baseDate);
  const deadlineDate = immediate ? cycleStart : addDays(cycleStart, 30);
  const reminderDate = immediate ? cycleStart : addDays(cycleStart, 27);

  return {
    id: index + 1,
    title: `Month ${index + 1}`,
    monthLabel: `Installment ${index + 1}`,
    cycleStart: cycleStart.toISOString(),
    reminderDate: reminderDate.toISOString(),
    deadlineDate: deadlineDate.toISOString(),
    paid: false,
    paidOn: '',
    reminderSent: false,
    transactionId: ''
  };
};

export const createBillingPlan = () => {
  const now = new Date();

  return Array.from({ length: 6 }, (_, index) =>
    index === 0
      ? createInstallment(index, now, true)
      : {
          id: index + 1,
          title: `Month ${index + 1}`,
          monthLabel: `Installment ${index + 1}`,
          cycleStart: '',
          reminderDate: '',
          deadlineDate: '',
          paid: false,
          paidOn: '',
          reminderSent: false,
          transactionId: ''
        }
  );
};

export const scheduleNextInstallment = (billingPlan, currentMonthId, paymentDate = new Date()) => {
  return billingPlan.map((month) => {
    if (month.id !== currentMonthId + 1 || month.paid) {
      return month;
    }

    const nextInstallment = createInstallment(currentMonthId, paymentDate, false);

    return {
      ...month,
      cycleStart: nextInstallment.cycleStart,
      reminderDate: nextInstallment.reminderDate,
      deadlineDate: nextInstallment.deadlineDate,
      monthLabel: nextInstallment.monthLabel
    };
  });
};

const defaultStore = {
  students: [],
  schoolCodes: []
};

const normalizeSchoolCode = (entry, index) => ({
  id: entry.id ?? `${Date.now()}-${index}`,
  schoolName: (entry.schoolName || entry.name || 'School Partner').trim(),
  code: (entry.code || '').trim().toUpperCase(),
  createdAt: entry.createdAt || new Date().toISOString()
});

const normalizeStudent = (student) => {
  const accessType = student.accessType === 'school' ? 'school' : 'direct';

  return {
    name: (student.name || '').trim(),
    username: (student.username || '').trim(),
    email: (student.email || '').trim().toLowerCase(),
    institution: (student.institution || '').trim(),
    password: student.password || '',
    accessType,
    studentId: (student.studentId || '').trim().toUpperCase(),
    schoolCode: (student.schoolCode || '').trim().toUpperCase(),
    billingPlan:
      accessType === 'direct'
        ? Array.isArray(student.billingPlan) && student.billingPlan.length === 6
          ? student.billingPlan.map((month, index) => ({
              id: month.id ?? index + 1,
              title: month.title ?? `Month ${index + 1}`,
              monthLabel: month.monthLabel || `Installment ${index + 1}`,
              cycleStart: month.cycleStart || '',
              reminderDate: month.reminderDate || '',
              deadlineDate: month.deadlineDate || '',
              paid: Boolean(month.paid),
              paidOn: month.paidOn || '',
              reminderSent: Boolean(month.reminderSent),
              transactionId: month.transactionId || ''
            }))
          : createBillingPlan()
        : [],
    assignmentSubmissions: Array.isArray(student.assignmentSubmissions)
      ? student.assignmentSubmissions.map((submission) => ({
          unitId: Number(submission.unitId),
          fileName: submission.fileName || '',
          submitted: Boolean(submission.submitted),
          submittedAt: submission.submittedAt || '',
          status: submission.status || 'pending',
          feedback: submission.feedback || '',
          notes: submission.notes || ''
        }))
      : [],
    projectSubmitted: Boolean(student.projectSubmitted),
    projectSubmittedAt: student.projectSubmittedAt || '',
    projectStatus: student.projectStatus || 'not_submitted',
    projectFeedback: student.projectFeedback || '',
    projectFileName: student.projectFileName || '',
    arenaBestScore: Number(student.arenaBestScore || 0),
    createdAt: student.createdAt || new Date().toISOString()
  };
};

const canUseStorage = () => typeof window !== 'undefined' && Boolean(window.localStorage);

const readStore = () => {
  if (!canUseStorage()) {
    return defaultStore;
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);

    if (!raw) {
      return defaultStore;
    }

    const parsed = JSON.parse(raw);

    return {
      students: Array.isArray(parsed.students)
        ? parsed.students.map(normalizeStudent)
        : [],
      schoolCodes: Array.isArray(parsed.schoolCodes)
        ? parsed.schoolCodes
            .map(normalizeSchoolCode)
            .filter((entry) => entry.code)
        : []
    };
  } catch {
    return defaultStore;
  }
};

const writeStore = (store) => {
  if (!canUseStorage()) {
    return;
  }

  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
};

export const getPlatformMode = () =>
  hasFirebaseConfig
    ? 'Firebase-ready placeholder mode'
    : 'Local demo mode (Firebase placeholders not configured yet)';

export const getAllStudents = () => readStore().students;

export const getAllSchoolCodes = () => readStore().schoolCodes;

export const createSchoolCode = ({ schoolName, code }) => {
  const normalizedCode = code.trim().toUpperCase();
  const normalizedSchoolName = schoolName.trim();
  const store = readStore();

  if (!normalizedSchoolName || !normalizedCode) {
    throw new Error('School name and school code are required.');
  }

  if (store.schoolCodes.some((entry) => entry.code === normalizedCode)) {
    throw new Error('This school code already exists.');
  }

  const schoolCode = normalizeSchoolCode({
    id: `${Date.now()}-${normalizedCode}`,
    schoolName: normalizedSchoolName,
    code: normalizedCode,
    createdAt: new Date().toISOString()
  });

  writeStore({
    ...store,
    schoolCodes: [...store.schoolCodes, schoolCode]
  });

  return schoolCode;
};

export const registerStudent = ({
  name,
  username,
  email,
  institution,
  password,
  accessType = 'direct',
  studentId = '',
  schoolCode = ''
}) => {
  const normalizedName = name.trim();
  const normalizedUsername = username.trim();
  const normalizedEmail = email.trim().toLowerCase();
  const normalizedInstitution = institution.trim();
  const normalizedAccessType = accessType === 'school' ? 'school' : 'direct';
  const normalizedStudentId = studentId.trim().toUpperCase();
  const normalizedSchoolCode = schoolCode.trim().toUpperCase();
  const store = readStore();

  if (!normalizedName || !normalizedUsername || !normalizedEmail || !normalizedInstitution || !password) {
    throw new Error('Name, username, email, password, and school or college are required.');
  }

  if (store.students.some((student) => student.email === normalizedEmail)) {
    throw new Error('A student account with this email already exists.');
  }

  if (
    store.students.some(
      (student) => student.username.trim().toLowerCase() === normalizedUsername.toLowerCase()
    )
  ) {
    throw new Error('This username already exists.');
  }

  if (normalizedAccessType === 'school') {
    if (!normalizedStudentId) {
      throw new Error('Student ID is required for school login.');
    }

    if (!store.schoolCodes.some((entry) => entry.code === normalizedSchoolCode)) {
      throw new Error('Invalid school code. Please enter a code created by admin.');
    }

    if (store.students.some((student) => student.studentId === normalizedStudentId)) {
      throw new Error('This student ID already exists.');
    }
  }

  const student = normalizeStudent({
    name: normalizedName,
    username: normalizedUsername,
    email: normalizedEmail,
    institution: normalizedInstitution,
    password,
    accessType: normalizedAccessType,
    studentId: normalizedStudentId,
    schoolCode: normalizedSchoolCode,
    billingPlan: normalizedAccessType === 'direct' ? createBillingPlan() : [],
    assignmentSubmissions: [],
    projectSubmitted: false,
    projectSubmittedAt: '',
    projectStatus: 'not_submitted',
    projectFeedback: '',
    projectFileName: '',
    arenaBestScore: 0,
    createdAt: new Date().toISOString()
  });

  writeStore({
    ...store,
    students: [...store.students, student]
  });

  return student;
};

export const loginStudent = ({
  name = '',
  username = '',
  email = '',
  institution = '',
  password,
  accessType = 'direct',
  studentId = ''
}) => {
  const store = readStore();
  const normalizedAccessType = accessType === 'school' ? 'school' : 'direct';
  const normalizedName = name.trim().toLowerCase();
  const normalizedUsername = username.trim().toLowerCase();
  const normalizedEmail = email.trim().toLowerCase();
  const normalizedInstitution = institution.trim().toLowerCase();
  const normalizedStudentId = studentId.trim().toUpperCase();

  const student = store.students.find((entry) => {
    const matchesBase =
      entry.accessType === normalizedAccessType &&
      entry.email === normalizedEmail &&
      entry.username.trim().toLowerCase() === normalizedUsername &&
      entry.name.trim().toLowerCase() === normalizedName &&
      entry.institution.trim().toLowerCase() === normalizedInstitution;

    if (!matchesBase) {
      return false;
    }

    return normalizedAccessType === 'school' ? entry.studentId === normalizedStudentId : true;
  });

  if (!student || student.password !== password) {
    throw new Error(
      normalizedAccessType === 'school'
        ? 'Invalid school student details or password.'
        : 'Invalid student details or password.'
    );
  }

  return student;
};

export const updateStudent = (email, updater) => {
  const normalizedEmail = email.trim().toLowerCase();
  const store = readStore();
  const index = store.students.findIndex((student) => student.email === normalizedEmail);

  if (index === -1) {
    throw new Error('Student not found.');
  }

  const currentStudent = normalizeStudent(store.students[index]);
  const nextStudent = normalizeStudent(
    typeof updater === 'function'
      ? updater(currentStudent)
      : { ...currentStudent, ...updater }
  );

  const nextStudents = [...store.students];
  nextStudents[index] = nextStudent;
  writeStore({ ...store, students: nextStudents });

  return nextStudent;
};
